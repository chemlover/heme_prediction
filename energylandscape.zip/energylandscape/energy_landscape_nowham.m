%pdb_array= {'Abeta42_2' 'Abeta420' 'Abeta40_2'
pdb_array= {'tau'};
%sim_labels = [4 4 4];
sim_labels = [12];
binN=15;ObinN=15;
cutoff=10;
newpoints1 =30;
newpoints2 =30;
% what data to loadout_file.txt
q_name={  'Rg_302.txt','Dee_302.txt' };
T=300
%xy_limit=1; % whose range to use for plotting, 1 or 2?
n_contour=20; % # of contour lines
xsym='Rg'
ysym='N C terminal Distance'
titlename='1'


%q_name = {'lpql_total','lpe_total'};xsym='Q_{Lig-Pro}',ysym='E_{Lig-Pro}',
%q_name = {'lpqw_total','lpe_total'};xsym='Q_{Pro}',ysym='E_{Lig-Pro}',
q_name = {'q2_total','q1_total'};xsym='Q open',ysym='Q closed',
%q_name = {'lpqw_total','lpe2_total'};xsym='Q closed',ysym='E heme-His',
%q_name = {'lpqw_total','lpe5_total'};xsym='Q closed',ysym='E HB backbone',
%q_name = {'lpqw_total','lpe6_total'};xsym='Q closed',ysym='E HB sidechain',
%q_name = {'lpqw_total','lpe7_total'};xsym='Q closed',ysym='E burial',

fsize=20; tsize=20; mr=1; mc=length(sim_labels);
%titlename = 'noCoA-3erd'
%titlename = 'unbias'

scrnsize = get(0,'ScreenSize'); 
figure('position', [1 scrnsize(4) 0.25*mc*scrnsize(3) 0.35*scrnsize(4)]);

for i_label=1:1
    %protein_i = i_label; pdbID_upper = pdb_array{protein_i};
    path = '/home/xun/wei/allosteric/test2/closed/'
    %titlename = num2str(i_label)
    %q_name = {['phi',titlename,'.txt'],['psi',titlename,'.txt']};xsym = 'phi';ysym = 'psi'
    %titlename = 'qwql'
    %q_name = {['twist50'],['50.dat']};xsym = 'Twist';ysym = 'Bending angle'
    sim_label = sim_labels(1);
    qa_name=q_name{1}; qb_name=q_name{2};
    
    filename = sprintf('%s/%s',path, qa_name); qa = load(filename);
    filename = sprintf('%s/%s',path, qb_name); qb = load(filename); %/3.14159*180 ;
    if strcmp(q_name{1},'dih')
        qa=(mean(qa'))';
    end
    if strcmp(q_name{2},'dih')
        qb=(mean(qb'))';
    end
    if i_label==1
        qa_min=min(qa); qa_max=max(qa);
        qb_min=min(qb); qb_max=max(qb);
    end
    Nsample=size(qa,1);
    %assert(Nsample==size(qb,1));
    %Nsample =length(qa)
    %load pmf file and calculate pi_sample
    T_i=T; T=T_i;    
    %filename = sprintf('%s/p_total',path); q = load(filename);
    %filename=sprintf('%s/%s_%d_pmf.dat',path,pdbID_upper, T_i);
    %filename=sprintfnbin=length(qa)('%s/small_300_pmf.dat',path);
    nbin=length(qa)
    pi_sample = zeros(Nsample,1); ni_sample = zeros(nbin, 1);
    qa_lin=linspace(min(qa), max(qa),ObinN); 
    qb_lin=linspace(min(qb), max(qb),binN); 
    H=zeros(ObinN,binN);
    [~, bin_index_x] = histc(qa, qa_lin); [~, bin_index_y] = histc(qb, qb_lin);
  % change for -nktln(c1/c0)
    %for i_sample = 1:Nsample
     %   x=bin_index_x(i_sample); y=bin_index_y(i_sample);
      %  if qa_lin(x) ~=  5
       %   qb(i_sample)=qb(i_sample)-qa_lin(x)*0.001987*T*log(0.0002705*(5-qa_lin(x)));
        %  pi_sanewpoq_name = {'dist_DD','Q_3erd'};xsym='distance DBD-DBD',ysym='Qw-3erd'ints = 10;mple(i_sample)=pi_sample(i_sample)*0.0002705*(5-qa_lin(x))*exp(-qa_lin(x)*0.001987*T);
        %end
    %end
    %qb_lin=linspace(min(qb), max(qb),binN);
    %[~, bin_index_x] = histc(qa, qa_lin); [~, bin_index_y] = histc(qb, qb_lin);
    delta = 1.0/nbin
    for i_sample = 1:Nsample
        x=bin_index_x(i_sample); y=bin_index_y(i_sample);
        H(x,y) = H(x,y) + delta;   
    end
    H=H'; fprintf('sum(sum(H))=%.3f\n', sum(sum(H)));     
    F=-0.001987*T*log(H);
    stone1 = min(min(F))
    %ids = (F>= cutoff); F(ids) =/home/xc25/Data_dealing/tau_agggregagtion/cluster1/monomer -inf;
    stone2 = max(max(F))
    %ids = (F<=stone1); F(ids) = cutoff;
    ids = (F>=cutoff); F(ids) = cutoff;
    subplot(mr,mc,1)
    [~,h] = contourf(qa_lin, qb_lin,F,n_contour,'edgecolor','none'); shading flat;
    
    %[xnew,ynew]=meshgrid(linspace(min(qa),max(qa),newpoints1),linspace(min(qb),max(qb),newpoints2))
    %[xnew,ynew]=meshgrid(linspace(-8,4,newpoints),linspace(-4,4,newpoints))
    %ids = (F>= cutoff-2); F(ids) = cutoff+30;
    %znew=interp2(qa_lin,qb_lin,F,xnew,ynew,'spline')
    %ids = (znew>=cutoff-1);znew(ids) = cutoff
    %[~,h] = contourf(xnew,ynew,znew,n_contour,'edgecolor','none'); shading flat
    
    colormap(jet), col=colorbar, %set(col,'ylim',[0 10])name
    cm=colormap;
    
    cm(64, :) = [1 1 1];
    colormap(cm);
    %title([num2str(pdbID_upper6235), ' T= ', num2str(T)],'fontsize', fsize);
    %title([ 'T= ', num2str(T),'fontsize', fsize);
    %%%fill the top area white
    ccc = get(h,'children'); max_cdata = -inf; cdata_list=zeros(size(ccc,1), 1);
    
    for k=1:size(ccc,1)
        cd1 = get(ccc(k), 'cdata');
        if cd1 > max_cdata
            max_cdata = cd1 ;
        end
        cdata_list(k) = get(ccc(k),'cdata');
    end
    id = find(cdata_list == max_cdata);
    disp(ccc(id));
    for k=1:size(id,1)
        set(ccc(id(k)), 'facecolor', 'white');
    end
    
    %xlabel(q_name{1}, 'fontsize', fsize), 
    %ylabe'
    fsize=40
    xlabel(xsym, 'fontsize', fsize)
    ylabel(ysym, 'fontsize', fsize)
    %xticks('fontsize', fsize)
    %yticks('fontsize', fsize)
    set(gca, 'FontSize', fsize/2);
    %xlim([qa_min, qa_max])
    %ylim([qb_min, qb_max])
    %xlim([-180,180])
   % title(titlename)
   % ylim([0,140])
    %xlim([40,180])
    %caxis([2,7])
   % xlim([0,25])
    %title(titlename,'fontsize', fsize)
    %caxis([0 12])
    %title(titlename)
   % caxis([0,7])
    saveas(gcf,[path,'/',q_name{1},'-',q_name{2},'.png'])
end
